(function ($, root, undefined) {
	$(function() {
		'use strict';
    
	});
})(jQuery, this);


