<div class="below-title warning warning-notice inline-message">
	<?php
	printf( __( '<p><strong>PHP Upgrade Required</strong> &mdash; Your server is currently running PHP %s but the Theme & Plugin Files addon requires PHP 5.4 or above. Please contact your web host and request a free upgrade to a server running <a href="%s" target="_blank">the version of PHP recommended by WordPress</a>.</p>
<p><em>To dismiss this message, simply deactivate the Theme & Plugin Files addon.</em></p>', 'wp-migrate-db' ), phpversion(), 'https://wordpress.org/about/requirements/');
	?>
</div>
